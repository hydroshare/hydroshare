
## Timeseries plotting

Start a simple HTTP server locally

```
python -m SimpleHTTPServer 8000
```

Launch the timeseries HTML page: index.html


Launch in Binder:

```
https://mybinder.org/v2/..../?urlpath=/proxy/5000/covid-app
```
